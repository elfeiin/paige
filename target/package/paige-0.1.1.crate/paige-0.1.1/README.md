# paige
A simple HTML templating API.
Credit to cyanidee for design discussion.
